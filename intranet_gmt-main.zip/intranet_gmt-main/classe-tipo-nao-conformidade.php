<?php
class Tipo_Nao_Conformidade{
	public $id;
	public $nome;
}

?>