<?php
class Loja{
	public $idLoja;
	public $nomeLoja;
	public $AGLoja;
	public $cnpjLoja;
}

?>