<?php
class Relacao_lojas_regionais{
    public $idLojasRegionais;
	public $regional;
    public $loja;
    public $data;
}

?>