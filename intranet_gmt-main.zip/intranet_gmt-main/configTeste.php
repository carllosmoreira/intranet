﻿<?php
$host="localhost";
$user="root";
$pass="";
$d_b="banco_controle";

$con = mysqli_connect($host, $user, $pass, $d_b);


?>
