<?php
class Nao_Conformidade{
	public $id;
	public $filial;
	public $funcionario;
	public $naoConformidade;
	public $qtd;	
	public $data;
}

?>