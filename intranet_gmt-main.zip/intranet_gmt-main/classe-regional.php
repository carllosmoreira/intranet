<?php
class Regional{
	public $idRegional;
    public $regional;
}

?>