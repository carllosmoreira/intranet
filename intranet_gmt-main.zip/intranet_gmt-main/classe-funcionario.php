<?php
class Funcionario{
	public $idFunc;
	public $nomeFunc;
	public $cpfFunc;
	public $idLojaFunc;
	public $funcaoFunc;
	public $ativo;
}

?>